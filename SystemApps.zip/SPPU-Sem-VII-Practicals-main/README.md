# SPPU-Sem-VII-Practicals

SPPU Semester VII Practical Codes for LP-III & LP-IV
