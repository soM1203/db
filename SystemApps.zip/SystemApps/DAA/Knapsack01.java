import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

class Knapsack01DP {


    public int knapSack(int capacity, int[] wt, int[] val) {
        int n = wt.length;
        int[][] dp = new int[n + 1][capacity + 1];


        for (int i = 1; i <= n; i++) {
            for (int w = 0; w <= capacity; w++) {
                if (wt[i - 1] <= w) {
                    dp[i][w] = Math.max(
                            dp[i - 1][w],
                            val[i - 1] + dp[i - 1][w - wt[i - 1]]
                    );
                } else {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }


        List<Integer> chosen = new ArrayList<>();
        int w = capacity;
        for (int i = n; i >= 1; i--) {
            if (dp[i][w] != dp[i - 1][w]) {
                chosen.add(i - 1);
                w -= wt[i - 1];
            }
        }
        Collections.reverse(chosen);


        System.out.println("Items Selected (index: weight,value):");
        int totalW = 0, totalV = 0;
        for (int idx : chosen) {
            System.out.println(idx + ": (" + wt[idx] + "," + val[idx] + ")");
            totalW += wt[idx];
            totalV += val[idx];
        }
        System.out.println("Total Weight = " + totalW +
                ", Total Value = " + totalV);

        return dp[n][capacity];
    }
}


public class Knapsack01 {
    public static void main(String[] args) {

        int[] weights = { 10, 20, 30 };
        int[] values = { 60, 100, 120 };
        int capacity = 50;

        Knappsack01 knapsack = new Knappsack01();
        int bestValue = knapsack.knapSack(capacity, weights, values);

        System.out.println("Maximum Value Achievable = " + bestValue);
    }
}
















































































































class Knappsack01{

    // Returns max value and prints which items are chosen
    public int knapSack(int capacity, int[] wt, int[] val) {
        int n = wt.length;
        int[][] dp = new int[n + 1][capacity + 1];

        // Build DP Table
        for (int i = 1; i <= n; i++) {
            for (int w = 0; w <= capacity; w++) {
                if (wt[i - 1] <= w) {
                    dp[i][w] = Math.max(
                            dp[i - 1][w],
                            val[i - 1] + dp[i - 1][w - wt[i - 1]]
                    );
                } else {
                    dp[i][w] = dp[i - 1][w];
                }
            }
        }

        // Track selected items
        List<Integer> chosen = new ArrayList<>();
        int w = capacity;
        for (int i = n; i >= 1; i--) {
            if (dp[i][w] != dp[i - 1][w]) {
                chosen.add(i - 1);
                w -= wt[i - 1];
            }
        }
        Collections.reverse(chosen);

        // Print chosen items
        System.out.println("Items Selected (index: weight,value):");
        int totalW = 0, totalV = 0;
        for (int idx : chosen) {
            System.out.println(idx + ": (" + wt[idx] + "," + val[idx] + ")");
            totalW += wt[idx];
            totalV += val[idx];
        }
        System.out.println("Total Weight = " + totalW +
                ", Total Value = " + totalV);

        return dp[n][capacity];
    }
}



// 0/1 Knapsack (Dynamic Programming) – Short Theory + Function Explanation
//
//The 0/1 Knapsack problem is an optimization problem where each item can either be selected completely or not selected at all.
//The goal is to maximize the total value of selected items without exceeding the capacity of the knapsack. The program uses a Dynamic Programming approach to ensure an optimal
//result by solving smaller subproblems and storing their results in a table to avoid recomputation.
//
//The program creates a 2D DP array where the rows represent the number of items considered and the columns represent different weight limits.
//For each item, the algorithm checks if the item can fit within the current capacity. If it fits, it chooses the maximum value between including the item or excluding it. If it does not fit,
//the value is directly carried over from the previous row. After filling the table, the maximum achievable value is found at the last cell. Backtracking is then used to identify
//which items contributed to this optimal value.
//
//
//Functions / Methods Explanation (Short and Clear)
//
//knapSack(int capacity, int[] wt, int[] val)
//
//Implements Dynamic Programming logic
//Builds the DP table
//Decides whether to include or exclude each item
//Performs backtracking to determine selected items
//Prints results and returns maximum value
//



// Class: MainKnapsack
// main(String[] args)
//
//Initializes input (weights, values, capacity)
//Creates object of Knapsack01DP class
//Calls knapSack() method to solve the problem
//Prints final maximum value
//

// Conclusion
//This program efficiently solves the 0/1 Knapsack problem using Dynamic Programming.
// It guarantees the optimal solution by evaluating all item-weight combinations systematically and then tracing back to find the chosen items.
