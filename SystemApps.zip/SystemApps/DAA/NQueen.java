import javax.xml.crypto.KeySelector;
import java.sql.Time;
import java.util.Arrays;
import java.util.Scanner;


class nQueen {

    char[][] board;
    boolean[] col;
    boolean[] diag1;
    boolean[] diag2;
    int n, firstR, firstC;


    public void initialize(int n, int r1, int c1) {
        this.n = n;
        this.firstR = r1 - 1;
        this.firstC = c1 - 1;

        board = new char[n][n];
        for (char[] row : board) Arrays.fill(row, '.');

        col = new boolean[n];
        diag1 = new boolean[2 * n - 1];
        diag2 = new boolean[2 * n - 1];


        board[firstR][firstC] = 'Q';
        col[firstC] = true;
        diag1[firstR - firstC + (n - 1)] = true;
        diag2[firstR + firstC] = true;
    }


    public boolean solve(int row) {
        if (row == n) return true;

        if (row == firstR) return solve(row + 1);

        for (int c = 0; c < n; c++) {
            if (isSafe(row, c)) {
                place(row, c);
                if (solve(row + 1)) return true;
                remove(row, c);
            }
        }
        return false;
    }


    boolean isSafe(int r, int c) {
        if (r == firstR && c == firstC) return false;
        return !col[c] && !diag1[r - c + (n - 1)] && !diag2[r + c];
    }


    void place(int r, int c) {
        board[r][c] = 'Q';
        col[c] = true;
        diag1[r - c + (n - 1)] = true;
        diag2[r + c] = true;
    }


    void remove(int r, int c) {
        board[r][c] = '.';
        col[c] = false;
        diag1[r - c + (n - 1)] = false;
        diag2[r + c] = false;
    }


    public void printBoard() {
        System.out.println("Solution:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }
}




public class NQueen {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter value of n: ");
        int n = sc.nextInt();

        System.out.print("Enter first queen row (1-based index): ");
        int r1 = sc.nextInt();

        System.out.print("Enter first queen column (1-based index): ");
        int c1 = sc.nextInt();

        sc.close();

        Nquen solver = new Nquen();
        solver.initialize(n, r1, c1);

        if (solver.solve(0)) {
            solver.printBoard();
        } else {
            System.out.println("No solution exists for the given queen position.");
        }
    }
}







































































































class Nquen {

    char[][] board;
    boolean[] col;
    boolean[] diag1;
    boolean[] diag2;
    int n, firstR, firstC;

    // Initialize the board and helper arrays
    public void initialize(int n, int r1, int c1) {
        this.n = n;
        this.firstR = r1 - 1; // 0-based
        this.firstC = c1 - 1; // 0-based

        board = new char[n][n];
        for (char[] row : board) Arrays.fill(row, '.');

        col = new boolean[n];
        diag1 = new boolean[2 * n - 1];
        diag2 = new boolean[2 * n - 1];

        // Place the given queen and mark attacks
        board[firstR][firstC] = 'Q';
        col[firstC] = true;
        diag1[firstR - firstC + (n - 1)] = true;
        diag2[firstR + firstC] = true;
    }

    // Backtracking function
    public boolean solve(int row) {
        if (row == n) return true;

        if (row == firstR) return solve(row + 1);

        for (int c = 0; c < n; c++) {
            if (isSafe(row, c)) {
                place(row, c);
                if (solve(row + 1)) return true;
                remove(row, c);
            }
        }
        return false;
    }

    // Safety check
    boolean isSafe(int r, int c) {
        if (r == firstR && c == firstC) return false;
        return !col[c] && !diag1[r - c + (n - 1)] && !diag2[r + c];
    }

    // Place queen
    void place(int r, int c) {
        board[r][c] = 'Q';
        col[c] = true;
        diag1[r - c + (n - 1)] = true;
        diag2[r + c] = true;
    }

    // Remove queen (Backtracking step)
    void remove(int r, int c) {
        board[r][c] = '.';
        col[c] = false;
        diag1[r - c + (n - 1)] = false;
        diag2[r + c] = false;
    }

    // Print solution
    public void printBoard() {
        System.out.println("Solution:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
    }
}





//N-Queen Problem (Backtracking) – Theory + Method Explanation
//The N-Queen Problem aims to place N queens on an N × N chessboard such that no two queens can attack each other. This means:
//No two queens are in the same row
//No two queens are in the same column
//No two queens share the same diagonal
//
//In this version of the program, one queen is pre-placed at a specific row and column given by the user.
//The algorithm must then place the remaining queens without violating any constraints.
//
//The program uses backtracking, which tries placing queens row by row.
//If placing a queen leads to a conflict later, the algorithm undoes the placement and tries a different position.
//This continues until a valid configuration is found for all rows.
//
//   Class: NQueen — Logic & Operations
//   initialize(int n, int r1, int c1)
//
//Sets board size and creates chessboard
//Marks initial positions as empty (.)
//Converts user input to 0-based index
//Places the first queen at fixed position
//Initializes boolean arrays for:
//
//Columns
//Left diagonals (r - c + offset)
//Right diagonals (r + c)
//Marks attacked positions as blocked
//
// Purpose: Prepare board and mark conflicts before solving
//
//solve(int row)
//
//Recursive backtracking method
//Tries to place a queen row-by-row
//Automatically skips the row containing the pre-placed queen
//For each column → checks safety → places queen temporarily → moves to next row
//If any placement fails, it removes the queen and tries next column
//
//Purpose: Find valid arrangement of all queens
//
//isSafe(int r, int c)
//Checks whether a position is safe by verifying:
//Column not used
//Diagonal 1 not used
//Diagonal 2 not used
//Prevents placing another queen on the pre-placed cell
//
// Purpose: Ensure no attack happens before placing a queen
//place(int r, int c)
//Places a queen at specified position
//Marks the column and diagonals as occupied
//
//
//
//Purpose: Temporarily choose a valid position
//remove(int r, int c)
//Removes queen from board during backtracking
//Frees marks on columns and diagonals
//Purpose: Undo wrong choices and try new possibilities
//
//
//
//printBoard()
//Displays the final solution chessboard
//‘Q’ for queen, ‘.’ for empty cell
//KeySelector.Purpose: Output the final valid arrangement
//
//
//
//Class: MainNQueen — Program Entry
// main(String[] args)
//Takes user input for board size and fixed queen position
//Creates object of NQueen class
//Calls initialization and solving functions
//Prints solution if found, otherwise shows “No solution exists”
//Purpose: Start and control full program execution
//
//Conclusion
//This program successfully solves the N-Queen problem using backtracking, ensuring a solution
//where queens do not attack each other. It also handles the additional restriction of one queen being pre-placed
//on the board, increasing the challenge while still guaranteeing correctness through systematic search and undo operations.




