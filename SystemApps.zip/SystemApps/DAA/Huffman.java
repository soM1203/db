import javax.xml.stream.events.Characters;

class Hufman {

    // Inner Node class
    class Node {
        char ch;
        int freq;
        Node left, right;

        Node(char ch, int freq) {
            this.ch = ch;
            this.freq = freq;
            this.left = this.right = null;
        }
    }

    private Node root;
    private Node[] nodes;
    private int count;

    // Initialize leaf nodes
    public void setData(char[] chars, int[] freq) {
        int n = chars.length;
        nodes = new Node[2 * n];
        count = n;

        for (int i = 0; i < n; i++) {
            nodes[i] = new Node(chars[i], freq[i]);
        }
    }

    // Function to build Huffman Tree
    public void buildTree() {
        int n = count;
        for (int i = 1; i < n; i++) {
            int[] smallest = findTwoSmallest();
            int first = smallest[0];
            int second = smallest[1];

            Node newNode = new Node('-', nodes[first].freq + nodes[second].freq);
            newNode.left = nodes[first];
            newNode.right = nodes[second];

            nodes[first] = null;
            nodes[second] = null;

            nodes[count] = newNode;
            count++;
        }

        for (int i = 0; i < nodes.length; i++) {
            if (nodes[i] != null) {
                root = nodes[i];
                break;
            }
        }
    }

    // Find two nodes with smallest frequencies
    private int[] findTwoSmallest() {
        int first = -1, second = -1;
        for (int i = 0; i < nodes.length; i++) {
            if (nodes[i] == null) continue;

            if (first == -1 || nodes[i].freq < nodes[first].freq) {
                second = first;
                first = i;
            } else if (second == -1 || nodes[i].freq < nodes[second].freq) {
                second = i;
            }
        }
        return new int[] { first, second };
    }

    // Print Huffman codes
    public void printCodes() {
        System.out.println("Huffman Codes:");
        printRecursive(root, "");
    }

    private void printRecursive(Node root, String code) {
        if (root == null) return;

        if (root.left == null && root.right == null) {
            System.out.println(root.ch + " : " + code);
            return;
        }

        printRecursive(root.left, code + "0");
        printRecursive(root.right, code + "1");
    }
}



public class Huffman {
    public static void main(String[] args) {

        char[] chars = { 'A', 'B', 'C', 'D', 'E', 'F' };
        int[] freq  = { 5, 9, 12, 13, 16, 45 };

        Huffmann h = new Huffmann();
        h.setData(chars, freq);
        h.buildTree();
        h.printCodes();
    }
}































































































class Huffmann {

    // Inner Node class
    class Node {
        char ch;
        int freq;
        Node left, right;

        Node(char ch, int freq) {
            this.ch = ch;
            this.freq = freq;
            this.left = this.right = null;
        }
    }

    private Node root;
    private Node[] nodes;
    private int count;

    // Initialize leaf nodes
    public void setData(char[] chars, int[] freq) {
        int n = chars.length;
        nodes = new Node[2 * n];
        count = n;

        for (int i = 0; i < n; i++) {
            nodes[i] = new Node(chars[i], freq[i]);
        }
    }

    // Function to build Huffman Tree
    public void buildTree() {
        int n = count;
        for (int i = 1; i < n; i++) {
            int[] smallest = findTwoSmallest();
            int first = smallest[0];
            int second = smallest[1];

            Node newNode = new Node('-', nodes[first].freq + nodes[second].freq);
            newNode.left = nodes[first];
            newNode.right = nodes[second];

            nodes[first] = null;
            nodes[second] = null;

            nodes[count] = newNode;
            count++;
        }

        for (int i = 0; i < nodes.length; i++) {
            if (nodes[i] != null) {
                root = nodes[i];
                break;
            }
        }
    }

    // Find two nodes with smallest frequencies
    private int[] findTwoSmallest() {
        int first = -1, second = -1;
        for (int i = 0; i < nodes.length; i++) {
            if (nodes[i] == null) continue;

            if (first == -1 || nodes[i].freq < nodes[first].freq) {
                second = first;
                first = i;
            } else if (second == -1 || nodes[i].freq < nodes[second].freq) {
                second = i;
            }
        }
        return new int[] { first, second };
    }

    // Print Huffman codes
    public void printCodes() {
        System.out.println("Huffman Codes:");
        printRecursive(root, "");
    }

    private void printRecursive(Node root, String code) {
        if (root == null) return;

        if (root.left == null && root.right == null) {
            System.out.println(root.ch + " : " + code);
            return;
        }

        printRecursive(root.left, code + "0");
        printRecursive(root.right, code + "1");
    }
}




















//📘 Huffman Coding Program – Full Theory Explanation (Function-wise)
//
//The purpose of the Huffman Coding program is to compress data by assigning shorter binary codes to characters that appear more frequently and longer codes
//to characters that appear less frequently. The program uses a special binary tree called a Huffman Tree to generate these codes. The overall idea is to reduce
//the number of bits needed to represent the characters in a text, helping in data compression.
//
//✅ Explanation of the Code in Easy Words (Paragraph Form)
//
//The program starts by storing characters along with their frequency (how many times they appear). Each character is turned into a node.
//All nodes are then stored in a structure where we can easily find the two smallest frequencies. These nodes are gradually combined to form
//a binary tree. In every step, the two nodes with the least frequency are joined to create a new node whose frequency becomes the sum of the two.
//        This new node then replaces the old ones and the process continues until only one node remains. This single node becomes the root of the Huffman Tree.
//
//Once the tree is ready, the program assigns binary codes to each character. It does this by travelling through the tree:
//        → Moving to the left child adds a ‘0’ to the code
//→ Moving to the right child adds a ‘1’ to the code
//
//When the program reaches a leaf node (the node containing a character), the binary code created through the path is printed.
//In this way, every character gets a unique code. Characters with a higher frequency get a shorter code and characters with lower frequency get a longer code.
//This makes the encoded text take less space compared to standard fixed-length encoding.
//
//        🔍 Explanation of Each Function
//✅ 1️⃣ Node Class
//
//This class is used to represent each character and its frequency in the program.
//It also has two links: one for the left child and one for the right child.
//        Internal nodes (not characters) only store frequency since they are formed by joining two nodes.
//
//        📌 Simple meaning:
//Node = A small storage unit that holds a character and connects to the Huffman Tree.
//
//        ✅ 2️⃣ findTwoSmallest(Node[] nodes)
//
//This function looks at all nodes and finds the two nodes that have the smallest frequency values.
//These smallest nodes are important because Huffman Coding always combines the least frequent characters first.
//The function returns the indexes of those two smallest nodes in the array.
//
//📌 Simple meaning:
//        “Go and find the two weakest (smallest) frequency nodes so we can join them.”
//
//        ✅ 3️⃣ buildHuffmanTree(char[] characters, int[] frequency)
//
//This is the main function that builds the Huffman Tree.
//It takes the input characters and their frequencies and makes them into separate nodes.
//Then, again and again, it calls the function findTwoSmallest() to find two nodes with the least frequencies and
//combines them into a new internal node.
//This new node’s frequency becomes the sum of the two joined nodes.
//This process continues until only one node remains, which becomes the root of the tree.
//
//        📌 Simple meaning:
//        “Join characters step-by-step from lowest frequency to highest to build the tree.”
//
//        ✅ 4️⃣ printCodes(Node root, String code)
//
//After the Huffman Tree is built, this function is used to print the Huffman Code for each character.
//It starts from the root node and moves left or right through the tree:
//
//If it goes Left → add 0
//
//If it goes Right → add 1
//
//Whenever it reaches a leaf node (a node containing an actual character), the function prints that character along with
//the generated binary code.
//
//        📌 Simple meaning:
//        “Walk in the tree and create a unique code for every character.”
//
//        ✅ 5️⃣ main() Function
//
//This is the starting point of the program.
//It defines the set of characters and their frequency values.
//Then it calls the buildHuffmanTree() function to construct the tree.
//Finally, it calls printCodes() to print the final Huffman codes for all characters.
//
//        📌 Simple meaning:
//        “Run the entire process — build the tree and show the final output.”
//
//        ✅ Final Summary (Nicely Written for Practical Journal)
//
//The Huffman Coding program is a data compression technique that uses variable-length codes based on character frequency.
//The program first creates nodes for each character and places them in a structure. Then, the nodes with the smallest frequencies are combined repeatedly
//to form a Huffman Tree. Once the tree is complete, binary codes are assigned by traversing the tree: left adds 0 and right adds 1.
//The final output displays the Huffman Codes, where frequently occurring characters have shorter codes. This makes the encoded data shorter and more efficient in storage and transmission.


