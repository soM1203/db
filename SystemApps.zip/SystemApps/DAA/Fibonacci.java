import java.util.Scanner;

class fibcaal{

    public int fibonacciRecursive(int n){
        if(n<=1){
            return n;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }

    public int fibonacciItterative(int n){
        if(n<=1){
            return n;
        }
        int prev = 0, curr = 1, next = 0;

        for (int i = 2; i <= n; i++) {
            next = prev + curr;
            prev = curr;
            curr = next;
        }
        return curr;
    }

}

public class Fibonacci{

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the value of n : ");
        int num = sc.nextInt();

        System.out.print("Enter the Method: 1. Itterative 2. Recursive = ");
        byte ch = sc.nextByte();

        fibcal fib = new fibcal();

        if (ch == 1){
            int ans = fib.fibonacciItterative(num);
            System.out.println("Answer ( Iterrative Method ) = "+ans);
        } else if (ch == 2) {
            int ans = fib.fibonacciRecursive(num);
            System.out.println("Answer ( Recursive Method ) = "+ans);
        }
        else {
            System.out.println("Invalid Output !!!");
        }

    }

}

















































































































































































class fibcal{

    public int fibonacciRecursive(int n){
        if(n<=1){
            return n;
        }
        return fibonacciRecursive(n - 1) + fibonacciRecursive(n - 2);
    }

    public int fibonacciItterative(int n){
        if(n<=1){
            return n;
        }
        int prev = 0, curr = 1, next = 0;

        for (int i = 2; i <= n; i++) {
            next = prev + curr;
            prev = curr;
            curr = next;
        }
        return curr;
    }
}















































































































//| Approach                      | Time Complexity | Space Complexity | Explanation                                                                                                                                            |
//| ----------------------------- | --------------- | ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
//| **Recursive**                 | **O(2ⁿ)**       | **O(n)**         | Each call spawns two recursive calls until base case is reached. The recursion tree grows exponentially. Space is proportional to recursion depth (n). |
//| **Iterative (Non-recursive)** | **O(n)**        | **O(1)**         | Single loop runs n times. Only a few variables are used for storing previous two values.
//
// Additional Notes
//
//Recursive Fibonacci is simple but inefficient — due to repeated calculations of the same subproblems (e.g., f(3) is computed multiple times).
//
//Iterative Fibonacci is efficient and suitable for large n.
//
//If you want a more optimized recursive approach, you can use memoization (Dynamic Programming) to reduce time complexity to O(n).|





//Problem Definition
//
//The Fibonacci sequence is a series of numbers where each term is the sum of the two preceding terms, starting from 0 and 1.
//
//
//The task is to compute the nth Fibonacci number using:
//
//Recursive method
//Non-recursive (Iterative) method and then compare their efficiency in terms of time and space complexity.
//
//        3. Recursive Approach (Top-Down)
//
//This approach directly follows the mathematical definition.=
//The function calls itself twice — once for F(n-1) and once for F(n-2).
//Each call breaks down into smaller subproblems until the base case is reached.
//
//Characteristics:
//Elegant but inefficient.
//Subproblems overlap heavily (same Fibonacci values are recomputed many times).
//Involves a large number of recursive function calls.
//Example Behavior:
//
//To find F(5), it will compute:
//F(5) = F(4) + F(3)
//F(4) = F(3) + F(2)
//F(3) = F(2) + F(1)
//...
//Many values like F(2) and F(3) are recalculated repeatedly.
//
//
//4. Non-Recursive (Iterative) Approach (Bottom-Up)
//Uses a simple loop structure to compute Fibonacci numbers one by one.
//Starts from the first two values (0 and 1) and builds up to F(n) by repeatedly adding the previous two numbers.
//No recursive function calls or stack usage.
//        Characteristics:
//More efficient and faster.
//Executes in linear time.
//Consumes constant space.
//        Suitable for large values of n.
//
//
//Dynamic Programming (Optimized Recursive Approach)
//Solves the inefficiency of recursion by storing previously computed results.
//Uses either:
//Memoization (Top-down): Stores results during recursion to avoid recomputation.
//Tabulation (Bottom-up): Builds the solution iteratively using a table or array.
//Ensures every Fibonacci value is computed only once.
//
//
//        6. Time Complexity Analysis
//Method	Time Complexity	Explanation
//Recursive	O(2ⁿ)	Each call spawns two more calls → exponential growth.
//Iterative	O(n)	Loop runs n times.
//Dynamic Programming	O(n)	Each Fibonacci value calculated once and reused.
//Matrix Exponentiation (Advanced)	O(log n)	Uses power of matrices for computation.
//
//
// 7. Space Complexity Analysis
//Method	Space Complexity	Reason
//Recursive	O(n)	Function call stack grows up to n levels.
//Iterative	O(1)	Only constant number of variables used.
//DP (Memoization)	O(n)	Stores results of all subproblems in array.
//DP (Tabulation)	O(1)	Uses only last two computed values.
//        \
//
//        🔹 8. Nature of the Problem
//
//Recursive Fibonacci exhibits overlapping subproblems and optimal substructure, making it a classic example for Dynamic Programming.
//
//These properties are key features of problems solvable by DP.