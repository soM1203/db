import java.util.ArrayList;
import java.util.Collections;

class item{

    int weight;
    int value;
    double ratio;

    item(int weight, int value){
        this.weight = weight;
        this.value = value;
        this.ratio = (double) value / weight;
    }
}


class knapsaack {

    public static double getMaxValue(int[] weight, int[] value, int capacity){

        int n = weight.length;
        ArrayList<Item> items = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            items.add(new Item(weight[i], value[i]));
        }


        Collections.sort(items, (a, b) -> Double.compare(b.ratio, a.ratio));

        double totalValue = 0.0;


        for (Item item : items) {
            if (capacity == 0)
                break;

            if (item.weight <= capacity) {

                totalValue += item.value;
                capacity -= item.weight;
            } else {

                totalValue += item.ratio * capacity;
                capacity = 0;
            }
        }

        return totalValue;


    }

}


public class Knapsack {
    public static void main(String[] args) {

        int[] weight = {10, 20, 30};
        int[] value = {60, 100, 120};
        int capacity = 50;

        Knapsaack k = new Knapsaack();
        double maxValue = k.getMaxValue(weight, value, capacity);
        System.out.println("Maximum value in Knapsack = " + maxValue);


    }
}






















































































































































class Item{

    int weight;
    int value;
    double ratio;

    Item(int weight, int value){
        this.weight = weight;
        this.value = value;
        this.ratio = (double) value / weight;
    }
}



class Knapsaack {

    public double getMaxValue(int[] weight, int[] value, int capacity){

        int n = weight.length;
        ArrayList<Item> items = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            items.add(new Item(weight[i], value[i]));
        }

        // Step 2: Sort items based on value/weight ratio in descending order
        Collections.sort(items, (a, b) -> Double.compare(b.ratio, a.ratio));

        double totalValue = 0.0;

        // Step 3: Select items
        for (Item item : items) {
            if (capacity == 0)
                break;

            if (item.weight <= capacity) {
                // Take whole item
                totalValue += item.value;
                capacity -= item.weight;
            } else {
                // Take fraction of item
                totalValue += item.ratio * capacity;
                capacity = 0;
            }
        }

        return totalValue;


    }

}





//✅ Fractional Knapsack → Take fractions only, not duplicates
//
//Correct selection in the code:
//
//        1️⃣ Take full 20kg → value 100
//        2️⃣ Take full 10kg → value 60
//        3️⃣ Remaining capacity = 50 – 30 = 20
//        → Take 20kg fraction out of 30kg item
//→ value = 120 × (20/30) = 80
//
//        📌 Total = 100 + 60 + 80 = 240
//
//This is the optimal solution ✅








//🧩 Fractional Knapsack Problem — Theory (Short)
//
//The Knapsack Problem is a classic optimization problem in which we must fill a knapsack of limited capacity with items to maximize total value.
//In the Fractional Knapsack variant, an item does not need to be taken completely; we can take fractions of items. This type of knapsack can be solved
//optimally using the Greedy Method. The greedy strategy selects items based on the highest value-to-weight ratio first, because items that provide more value per unit weight contribute more to profit.
//The process continues until the knapsack becomes full, at which point, if only part of the next item can fit, a fraction of it is taken.
//
//⚙️ Code Approach Explained (Short Steps as Paragraph)
//
//In the program, each item is represented with its weight, value, and its value/weight ratio. First, all items are stored in a list and then sorted in descending order of their ratio.
//Then we iterate through the sorted items and add them to the knapsack. If the whole item fits within the remaining capacity, we take it completely and decrease the knapsack capacity accordingly.
//If the remaining capacity is smaller than the item’s weight, we take only the required fraction of the item and then stop, as the knapsack is full. The total value collected during this process is the maximum possible value.
//
//        ✅ Result
//
//This greedy approach ensures an optimal solution for the fractional knapsack problem with O(n log n) time complexity because of sorting.
